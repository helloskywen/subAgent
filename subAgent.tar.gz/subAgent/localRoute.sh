#! /bin/bash

tmp1=/tmp/tmp1$$
tmp2=/tmp/tmp2$$
tmp3=/tmp/tmp3$$

/usr/local/net-snmp/bin/snmpwalk -c public -v 2c $1 ipRouteTable > $tmp3

cat $tmp3 |cut -d: -f4 > $tmp1

nlines=`wc -l $tmp1 |cut -d" " -f1`
nrows=`expr $nlines / 8`

for((i=0;$i<$nlines;$((i++))))
do
	read tmpline < $tmp1
	pole[$i]=$tmpline
	sed '1 d' $tmp1 > $tmp2
	tmp=$tmp1
	tmp1=$tmp2
	tmp2=$tmp
done


#echo Route Table 

#echo Destination$'\t'NextHop$'\t\t'Mask$'\t\t'Metic$'\t'Type$'\t\t'Protocol$'\t'IfIndex	> routetable.txt

tmpRoute=/tmp/localRoute
echo -n > $tmpRoute

for((i=0;$i<$nrows;$((i++))))
do
	
	echo -n ${pole[$((0*nrows+i))]} $'\t' >> $tmpRoute
	
	echo -n ${pole[$((3*nrows+i))]}	$'\t' >> $tmpRoute
	
	echo -n ${pole[$((6*nrows+i))]} $'\t' >> $tmpRoute
	
	echo -n	${pole[$((2*nrows+i))]}	$'\t' >> $tmpRoute
	
	echo -n ${pole[$((4*nrows+i))]}	$'\t' >> $tmpRoute
	
	echo -n ${pole[$((5*nrows+i))]} $'\t' >> $tmpRoute
	
	echo -n ${pole[$((1*nrows+i))]} $'\t' >> $tmpRoute
	echo >> $tmpRoute
done

#cat $tmpRoute

rm  /tmp/tmp*




